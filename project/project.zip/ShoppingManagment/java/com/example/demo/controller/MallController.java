package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.MallAdmin;
import com.example.demo.service.MallAdminService;

@RestController
public class MallController {
	
	@Autowired
	public MallAdminService ser;
	
	@PostMapping("/addAdmin")
	public MallAdmin regMallAdmin(@RequestBody MallAdmin mal)
	{
    return ser.addAdmin(mal);
	}
	
	@GetMapping("/getAdmin")
	public List<MallAdmin> getMal()
	{
	   return ser.getMallAdmin();
	}
	
	@DeleteMapping("deleteAdmin/{id}")
	public void deleteMal(@PathVariable Integer id) {
		ser.deleteMallAdmin(id);
	}
	
	@PutMapping("/updateAdmin")
	public MallAdmin updateAdmin(@RequestBody MallAdmin mal) {
		return ser.updateMallAdmin(mal);
	}
}
