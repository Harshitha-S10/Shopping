package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.MallAdmin;
import com.example.demo.repository.MadRepository;

@Service
public class MallAdminService {
	
	@Autowired
	public MadRepository mar;
	
	public MallAdmin addAdmin(MallAdmin mal)
	{
           return mar.save(mal);
}
	public List<MallAdmin> getMallAdmin(){
		return mar.findAll();
	}
	public void deleteMallAdmin(int id) {
		mar.deleteById(id);
	}
	public MallAdmin updateMallAdmin(MallAdmin mal) 
	{
		Integer id =mal.getId();
	MallAdmin mar1	=mar.findById(id).get();
	mar1.setName(mal.getName());
	return mar.save(mal);
	}
	
	}
